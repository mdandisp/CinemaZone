package com.dicoding.projekakhirplatformkelompok5.data.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Movie(
    @SerializedName("id")
    val id: Int,

    @SerializedName("title")
    val title: String,

    @SerializedName("overview")
    val overview: String,

    @SerializedName("poster_path")
    val posterPath: String?,

    @SerializedName("release_date")
    val releaseDate: String?,

    @SerializedName("vote_average")
    val voteAverage: Double,

    @SerializedName("trailer_url")
    val trailerUrl: String? = null,

    @SerializedName("genre")
    val genre: List<String>?,

    @SerializedName("showtimes")
    val showtimes: List<Showtime>?
) : Parcelable